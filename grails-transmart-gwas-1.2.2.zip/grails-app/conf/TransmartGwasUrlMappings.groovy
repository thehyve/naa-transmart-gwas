class TransmartGwasUrlMappings {

    static mappings = {

    }
}
